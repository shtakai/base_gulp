var _ = require('underscore');
var assert = require('power-assert');
var expect = require('chai').expect;

//var mathlib = require('../lib/mathlib.js');
describe('lib', function(){

  before(function(){
  })
  it('testname', function(){
    expect(something).to.be.equal(5);
  });

});
